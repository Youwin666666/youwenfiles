#include <iostream>
using namespace std;
int main()
{
    int n=0;
    int a[100];
    int count=0; 
    cin>>n;
    
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
    }
    for (int i=0;i<n;i++)
    {
        if (a[i]>5)
        count++;

    }
    cout<<count<<endl;

    return 0;

}
#include <iostream>
using namespace std;
int main(){
    int n=0;
    int w=0;
    cin>>n;
    cin>>w;
    
    if(n<w)
    {
        cout<<"error"<<endl;
    }
    else
    {
        cout<<n-w<<endl;
    }

    return 0;
}
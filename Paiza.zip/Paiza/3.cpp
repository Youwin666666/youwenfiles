#include<iostream>
#include<string>
using namespace std;
int main()
{
string str;
int i, j, count = 0;
cin >> str;
for (i = 0; str[i] !='\0'; i++)
count++;
for (j = 0; j <= count; j++)
{
if (j % 2 != 0)
cout << str[j - 1];
}

return 0;
}
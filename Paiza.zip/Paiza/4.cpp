#include <iostream>
using namespace std;
int main(){
    int a=0;
    int b=0;
    cin>>a>>b;
    int c=a+b;
    cout<<c%10<<endl;

    return 0;
}
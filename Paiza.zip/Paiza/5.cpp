#include <iostream>
using namespace std;
int main()
{ 
    int n=0;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        string s;
        int h;
        cin>>s>>h;
        
        if (h==3)
            cout<<s<<endl;
    }

    
    return 0;
}

#include <iostream>
using namespace std;
typedef long long lol;
int gi(){
    int res=0,fh=1;char ch=getchar();
    while((ch>'9'||ch<'0')&&ch!='-')ch=getchar();
    if(ch=='-')fh=-1,ch=getchar();
    while(ch>='0'&&ch<='9')res=res*10+ch-'0',ch=getchar();
    return fh*res;
}
struct tatemono{
    int h,w,r,c,id;
    bool operator <(const tatemono b) const{return h*w>b.h*b.w;}
}t[110];
int a[110][110];
bool place(int x,int y,int h,int w,int id){
    for(int i=0;i<h;i++)
        for(int j=0;j<w;j++)if(a[x+i][y+j])return 0;
    for(int i=-1;i<=h;i++)
        for(int j=-1;j<=w;j++)a[x+i][y+j]=-1;
    for(int i=0;i<h;i++)
        for(int j=0;j<w;j++)a[x+i][y+j]=id;
    return 1;
}
int main(){
    int H=gi(),W=gi(),n=gi();
    for(int i=1;i<=n;i++)t[i].h=gi(),t[i].w=gi(),t[i].r=gi(),t[i].c=gi(),t[i].id=i;
    sort(t+1,t+n+1);
    for(int i=1;i<=n;i++){
        if(t[i].r==1){
            for(int x=H-t[i].h+1;x>1;x--)
                for(int y=1;y<=W-t[i].w+1;y++)if(place(x,y,t[i].h,t[i].w,t[i].id))goto next;
        }else if(t[i].r==t[i].h){
            for(int x=1;x<=H-t[i].h;x++)
                for(int y=1;y<=W-t[i].w+1;y++)if(place(x,y,t[i].h,t[i].w,t[i].id))goto next;
        }else if(t[i].c==1){
            for(int y=W-t[i].w+1;y>1;y--)
                for(int x=1;x<=H-t[i].h+1;x++)if(place(x,y,t[i].h,t[i].w,t[i].id))goto next;
        }else{
            for(int y=1;y<=W-t[i].w;y++)
                for(int x=1;x<=H-t[i].h+1;x++)if(place(x,y,t[i].h,t[i].w,t[i].id))goto next;
        }
    next:;
    }
    for(int i=1;i<=H;i++){
        printf("%d",max(a[i][1],0));
        for(int j=2;j<=W;j++)printf(" %d",max(a[i][j],0));
        putchar('\n');
    }
    return 0;
}
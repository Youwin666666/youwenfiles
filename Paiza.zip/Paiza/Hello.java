public class Hello{
    public static void Main(){
        string line = System.Console.ReadLine();
            bool valid = true;
            int width = int.Parse(line.Split(' ')[0]);
            int height= int.Parse(line.Split(' ')[1]);
            int num= int.Parse(line.Split(' ')[2]);
            int x = 0;
            int y = 0;
            for(int i=0;i<num;i++)
            {
                string move = System.Console.ReadLine();
                if(move=="U")
                {
                    y++;
                    if (y > height)
                        valid = false;
                }
                else if (move == "R")
                {
                    x++;
                    if (x > width)
                        valid = false;
                }
               else if (move == "D")
                {
                    y--;
                    if (y < 0)
                        valid = false;
                }
                else//L
                {
                    x--;
                    if (x < 0)
                        valid = false;
                }
            }
            if(valid)
                System.Console.WriteLine("valid");
            else
                System.Console.WriteLine("invalid");
    }
}
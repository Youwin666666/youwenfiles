import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner input=new Scanner(System.in);

        int H=input.nextInt();
        int W=input.nextInt();//取得小镇的长宽
        int N=input.nextInt();//建筑物的个数

        int town[][]=new int[H][W];

        for (int i = 0; i < H; i++) {

            for (int j = 0; j < W; j++) {

                town[i][j]=0;

            }

        }//初始化小镇

        int[] h=new int[N],
                w=new int[N],
                r=new int[N],
                c=new int[N];

        int judge=0;//判断用参数
        int x[]=new int[N];//位置参数 for h
        int y[]=new int[N];//位置参数 for w

        for (int i = 0; i < N; i++) {
            h[i]=input.nextInt();
            w[i]=input.nextInt();
            r[i]=input.nextInt();
            c[i]=input.nextInt();
            x[i]=1;
            y[i]=1;
        }//取得所有建筑的参数并初始化x和y

        int[] h_l=new int[N],
                w_l=new int[N];//门在最右侧,将要放于最左侧的建筑物群
        int H_l=0;//其竖直总长


        for (int i = 0; i < N; i++) {

            if(c[i]==w[i] && H_l+h[i]<H ){

                H_l+=h[i];
                h_l[i]=h[i];
                w_l[i]=w[i];
                h[i]=0;
                w[i]=0;//转移数据

                x[i]=0;//将位置坐标移动至最左上

                while(x[i]<H) {

                    for (int j = 0; j < h_l[i]; j++) {


                        if (x[i] + j< H) {

                            if (town[x[i] + j][0] != 0) judge += 1;

                        } else {

                            judge += 1;

                        }
                    }//遍历建筑物即将摆放的竖直方向检查是否有建筑物

                    if (judge == 0) {

                        for (int j = 0; j < h_l[i]; j++) {

                            for (int k = 0; k < w_l[i]; k++) {

                                town[x[i] + j][k] = i + 1;
                            }
                        }//若没有建筑物,则对town坐标赋值并跳出while循环
                        break;
                    } else if (x[i] < H) {
                        x[i] += 1;
                        judge = 0;//初始化judge
                    }//若有, 则使x+=1, 继续while循环.
                }

                x[i]=1;//初始化x[i]
            }

        }

        for (int i = 0; i < N; i++) {
            //对编号为i的建筑进行操作

            while(x[i]<H&&y[i]<W)
            {


                for (int j = 0; j < h[i] + 2; j++) {


                    for (int k = 0; k < w[i] + 2; k++) {

                        if (x[i] + j -2< H - 1 && y[i] + k -2< W - 1) {
                            //减1留出地图周边位置

                            if (town[x[i] + j - 1][y[i] + k - 1] != 0) judge += 1;


                        } else {

                            judge += 1;

                        }
                    }
                }//遍历建筑物即将摆放的位置及其周边检查是否有建筑物

                if (judge == 0) {

                    for (int j = 0; j < h[i]; j++) {

                        for (int k = 0; k < w[i]; k++) {

                            town[x[i] + j][y[i] + k] = i + 1;
                        }
                    }//若没有建筑物,则对town坐标赋值并跳出while循环
                    break;
                } else if (x[i] < H - 1) {
                    x[i] += 1;
                    judge = 0;//初始化judge
                } else {
                    x[i] = 1;
                    y[i] += 1;
                    judge = 0;//初始化judge
                }//若有, 则改变x和y以遍历坐标, 并循环遍历
            }

            judge=0;//初始化judge

        }//遍历N个建筑物结束

        judge=0;//循环结束,初始化judge

        for (int i = 0; i < H; i++) {
            for (int j = 0; j < W; j++) {
                if(town[i][j]==0) judge+=1;
            }
        }//判断空白的个数

        if(judge==H*W){
            int square[]=new int[N];//各建筑的面积
            int the_max=0;//最大面积建筑对应的编号

            for (int i = 0; i <N; i++) {

                square[i]=h[i]*w[i];
                if(square[the_max]<=square[i]) the_max=i;

            }//计算编号为i的建筑物的面积并找出最大面积的建筑物

            for (int i = 0; i < h[the_max]; i++) {
                for (int j = 0; j < w[the_max]; j++) {
                    town[i][j]=the_max+1;
                }
            }//对town坐标赋值

        }//若所有town均为空白, 则找出面积最大的建筑物并放置于town中

        for (int i = 0; i < H; i++) {
            for (int q = 0; q < W; q++) {
                System.out.print(town[i][q]);
                if (q!=W-1) System.out.print(" ");
            }
            System.out.println();
        }//输出结果

    }

}